//
//  AboutMeAppApp.swift
//  AboutMeApp
//
//  Created by India Poetzscher on 4/22/23.
//

import SwiftUI

@main
struct AboutMeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
